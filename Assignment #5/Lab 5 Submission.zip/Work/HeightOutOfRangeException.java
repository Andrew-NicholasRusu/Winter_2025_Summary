class HeightOutOfRangeException extends Exception {
    public HeightOutOfRangeException(String message) {
        super(message);
    }
}
