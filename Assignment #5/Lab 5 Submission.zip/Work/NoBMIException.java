class NoBMIException extends Exception {
    public NoBMIException(String message) {
        super(message);
    }
}
