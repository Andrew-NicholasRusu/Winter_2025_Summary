class WeightOutOfRangeException extends RuntimeException {
    public WeightOutOfRangeException(String message) {
      super(message);
    }
}
