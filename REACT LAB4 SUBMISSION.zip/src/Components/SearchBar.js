import React from 'react';

function SearchBar({ searchTerm, onSearchChange }) {
    return (
        <div style={{ margin: '20px 0' }}>
            <input
                type="text"
                value={searchTerm}
                onChangeCapture={(e) => onSearchChange(e.target.value)}
                placeholder="Search books by title..."
                style={{ 
                    width: '100%', 
                    padding: '10px', 
                    fontSize: '16px',
                    marginBottom: '20px',
                    border: '1px solid #ccc',
                    borderRadius: '5px',
                }}
            />
        </div>
    );
}

export default SearchBar;