import React from 'react';

function BookCard({ title, authors, category, pageCount, thumbnailURL }) {
    return (
        <div style={{ border: '1px solid #ddd', margin: '10px', padding: '12px', display: 'fles',
            gap: '10px' }}>
        <img src={thumbnailURL} alt={title} style={{ width: '100px', height: 'auto' }} />
        <div>
            <h3>{title}</h3>
            <p>
                <strong>Author(s):</strong> {authors.length > 0 ? authors.join(', ')
            : 'Unknown'}
            </p>
            <p>
                <strong>Category:</strong> {category ? category : 'Unknown'}
            </p>
            <p>
                <strong>Page Count:</strong> {pageCount > 0 ? pageCount : 'Unknown'}
            </p>
            </div>
        </div>
    );
}

export default BookCard;