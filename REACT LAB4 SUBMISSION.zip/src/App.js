import React, { useState } from 'react';
import BookCard from './Components/BookCard';
import SearchBar from './Components/SearchBar';
import booksdata from './Data/books.json';

function App() {
  const [searchText, setSearchTerm] = useState('');

  const filteredBooks = booksdata.filter((book) =>
    book.title.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div style={{ maxWidth: '800px', margin: 'auto', padding: '20px' }}>
      <h1>Book List</h1>
      <SearchBar searchText={searchText} onSearchChange={setSearchTerm} />

      {filteredBooks.map((book) => (
        <BookCard
          key={book.id}
          title={book.title}
          authors={book.authors || []}
          category={book.category || ''}
          pageCount={book.pageCount}
          thumbnailURL={book.thumbnailUrl}
        />
      ))}

      {filteredBooks.length === 0 && <p>No books found!</p>}
    </div>
    );
}

export default App;