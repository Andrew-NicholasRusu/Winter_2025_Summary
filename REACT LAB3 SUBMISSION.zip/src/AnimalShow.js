import React from "react";
import bird from "./svg/bird.svg";
import cat from "./svg/cat.svg";
import cow from "./svg/cow.svg";
import dog from "./svg/dog.svg";
import gator from "./svg/gator.svg";
import horse from "./svg/horse.svg";

const svgMap = {
  bird,
  cat,
  cow,
  dog,
  gator,
  horse,
};

const AnimalShow = ({ type }) => {
  return (
    <div style={{ width: "10%", margin: "10px" }}>
      <img src={svgMap[type]} alt={type} style={{ width: "100%" }} />
    </div>
  );
};

export default AnimalShow;
// This code defines a React component called AnimalShow that takes a prop called type.
