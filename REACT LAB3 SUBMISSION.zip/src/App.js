import React, { useState } from "react";
import AnimalShow from "./AnimalShow";

const getRandomAnimal = () => {
  const animals = ["bird", "cat", "cow", "dog", "gator", "horse"];
  const randomIndex = Math.floor(Math.random() * animals.length);
  return animals[randomIndex];
};

function App() {
  const [animals, setAnimals] = useState([]);
  const [counts, setCounts] = useState({
    bird: 0,
    cat: 0,
    cow: 0,
    dog: 0,
    gator: 0,
    horse: 0,
  });

  const handleAddAnimal = () => {
    const newAnimal = getRandomAnimal();
    setAnimals([...animals, newAnimal]);
    setCounts((prevCounts) => ({
      ...prevCounts,
      [newAnimal]: prevCounts[newAnimal] + 1,
    }));
  };

  const handleReset = () => {
    setAnimals([]);
    setCounts({
      bird: 0,
      cat: 0,
      cow: 0,
      dog: 0,
      gator: 0,
      horse: 0,
    });
  };

  return (
    <div>
      <h1>Random Animal Generator</h1>
      <button onClick={handleAddAnimal}>Add Animal</button>
      <button onClick={handleReset}>Reset</button>

      <div>
        <h2>Animal Counts:</h2>
        <ul>
          {Object.entries(counts).map(([animal, count]) => (
            <li key={animal}>
              {animal}: {count}
            </li>
          ))}
        </ul>
      </div>

      <div style={{ display: "flex", flexWrap: "wrap" }}>
        {animals.map((animal, index) => (
          <AnimalShow type={animal} key={index} />
        ))}
      </div>
    </div>
  );
}

export default App;
