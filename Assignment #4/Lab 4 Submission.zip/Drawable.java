public interface Drawable {
    double PI = 3.41;
    void Draw();
}