import { useNavigate } from 'react-router-dom';

const Pagination = ({ currentPage, totalPages }) => {
    const navigate = useNavigate();

    const goToPage = (page) => {
        navigate(`/products/page/${page}`);
    };

    const pages = Array.from({ length: totalPages }, (_, i) => i + 1);

    return (
        <div style={styles.pagination}>
            {pages.map((page) => (
                <button
                    key={page}
                    onClick={() => goToPage(page)}
                    style={{
                        ...styles.button,
                        backgroundColor: page === currentPage ? '#ddd' : '#fff'
                    }}
                >
                    {page}
                </button>
            ))}
        </div>
    );
};

const styles = {
    pagination: {
        marginTop: 20,
        display: 'flex',
        justifyContent: 'center',
        gap: 10
    },
    button: {
        padding: '5px 10px',
        border: '1px solid #ccc',
        cursor: 'pointer'
    }
};

export default Pagination;

