import { useState } from "react";

const placeholderImage = "https://via.placeholder.com/150";

const ProductCard = ({ product }) => {
    const [imgSrc, setImgSrc] = useState(product.image || placeholderImage);

    return (
        <div style={styles.card}>
        <img
            src={imgSrc}
            alt={product.name || 'Unknowwn Product'}
            onError={() => setImgSrc(placeholderImage)}
            style={styles.image}
            />
            <h3>{product.name || 'Unknown Product'}</h3>
            <p>Model: {product.model || 'N/A'}</p>
            <p>Price: {product.price || 'Not Available'}</p>
        </div>
    );
};

const styles = {
    card: {
        border: '1px solid #ccc',
    borderRadius: '8px',
    padding: '16px',
    width: '300px', 
    boxSizing: 'border-box',
    textAlign: 'center'
    },
    image: {
        width: '100%',
        height: 280,
        objectFit: 'cover',
        borderRadius: 6
    }
};

export default ProductCard;