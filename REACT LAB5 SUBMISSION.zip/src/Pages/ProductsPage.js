import { useParams } from "react-router-dom";
import ProductCard from "../Components/ProductCard";
import Pagination from "../Components/Pagination";
import productsData from "../Data/products.json";

const PRODUCTS_PER_PAGE = 12;

const styles = {
  grid: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: '20px',
  },
};

const ProductsPage = () => {
  const { pageNumber } = useParams();
  const currentPage = parseInt(pageNumber) || 1;

  const start = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const paginatedProducts = productsData.slice(start, start + PRODUCTS_PER_PAGE);
  const totalPages = Math.ceil(productsData.length / PRODUCTS_PER_PAGE);

  return (
    <div style={{ padding: 20 }}>
      <h1 style={{ textAlign: 'left' }}>🛒 Product Store</h1>
      <h2 style={{ marginTop: 20 }}>Products - Page {currentPage}</h2>
      <div style={styles.grid}>
        {paginatedProducts.map((product, index) => (
          <ProductCard key={index} product={product} />
        ))}
      </div>
      <Pagination currentPage={currentPage} totalPages={totalPages} />
    </div>
  );
};

export default ProductsPage;
