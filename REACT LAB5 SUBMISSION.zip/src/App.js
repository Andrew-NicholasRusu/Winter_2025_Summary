import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import ProductsPage from "./Pages/ProductsPage";

const App = () => (
  <Router>
  <Routes>
    <Route path="/" element={<Navigate to="/products/page/1" replace />} />
    <Route path="/products/page/:pageNumber" element={<ProductsPage />} />
  </Routes>
  </Router>
);

export default App;
